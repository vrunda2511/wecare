import React from 'react'
import CreateLoginComponent  from '../components/SignIn/signin'

function Signin() {
    return (
        <div>
            <CreateLoginComponent />
        </div>
    )
}

export default Signin
