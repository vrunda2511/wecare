import React from 'react'
import CreateSignUpComponent from "../components/SignUp/signup";


function SignUp(){
    return (
        <div>
            <CreateSignUpComponent/>
        </div>
    )
}
export default SignUp