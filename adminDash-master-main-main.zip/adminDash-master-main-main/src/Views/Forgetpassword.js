import React from 'react'
import ForgetPasswordComponent  from '../components/Forgetpassword/forgetpassword'

function ForgetPassword() {
    return (
        <div>
            <ForgetPasswordComponent />
        </div>
    )
}

export default ForgetPassword
